# Pure Data source credits and notices

| Material | Included location | Notice |
| --- | --- | --- |
| Peter Neyra’s original software and documentation | Instrument wrappers, groove arrangements and project documentation | [MIT project licence](LICENSE), scoped to original contributions |
| CHAIR models and helpers | `pd/` and `pd/original-project/` | [Verbatim MIT notice](third_party/CHAIR/LICENSE); the same notice is beside the Pd files in `pd/LICENSE-CHAIR.txt` |
| CHAIR model/source correspondence | Original patches and audition derivatives | [Pinned source record](third_party/CHAIR/PROVENANCE.md) and `file-correspondence.json`, copied from the full source project |
| Chris Moore reverb by Tom Erbe, via CHAIR | `pd/chair.chrismoore-reverb~.pd` and archival copy | Exact match to the pinned CHAIR MIT example; existing patch credit retained |
| Pure Data examples by Miller Puckette and contributors | Recovered original-project examples | [Original Pure Data/libpd BSD notice](notices/LICENSE-PureData-libpd.txt), copied verbatim from the included engine source record |

The source correspondence record distinguishes exact upstream matches from recovered derivatives. Keep its CHAIR, Philipp Schmalfuß, Tom Erbe and other original author credits together with these notices. Pure Data Vanilla is installed separately; this download contains the patches and their supporting recordings.

The complete [Messier ’57 repository](https://github.com/latintzar/messier57-instrument) retains the browser runtime and additional dependency notices. CAD and visualisation files are supplied in that complete project.

[made by atelier neyra](https://atelierneyra.com)
