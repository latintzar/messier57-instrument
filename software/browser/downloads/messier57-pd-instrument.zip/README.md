# Messier ’57 — Pure Data instrument

Messier ’57 is an electric drum whose microphones excite a physically modelled snare. This download contains the portable Pure Data audition, original project patches, ten groove scores and hardware notes.

## Play

1. Install [Pure Data Vanilla](https://puredata.info/downloads/pure-data).
2. Open `pd/desktop.pd`, then `pd/grooves.pd` beside it.
3. Start at low output volume: the desktop patch enables DSP on load.

**H** plays the head, **R** the rim and **K** the kick. Hold **S** to loosen the snares. The desktop patch includes the snare and kick models, excitation recordings and CHAIR/Tom Erbe reverb. `pd/README.txt` preserves the original audition notes; its repository-relative paths refer to the complete source repository linked below.

## Files

| Path | Contents |
| --- | --- |
| `pd/desktop.pd` | Native audition controls and audio output |
| `pd/instrument.pd` | Unchanged CHAIR snare and kick models with the audition wrapper |
| `pd/grooves.pd`, `pd/grooves/` | Ten groove scores, each including kick |
| `pd/original-project/` | Historical hardware and Bonk patches and training templates |
| `hardware/` | BOM, specifications and assembly notes |
| `THIRD-PARTY.md`, `third_party/`, `notices/` | Upstream credits, licences and source correspondence |

The browser edition, original Rhino CAD, visualisation files and source manifest are in the [complete project](https://github.com/latintzar/messier57-instrument). Its [release downloads](https://github.com/latintzar/messier57-instrument/releases) include the complete source package. Existing Pd, WAV, groove and hardware files in this smaller download retain their reviewed bytes.

## Credits

Peter Neyra: original instrument design, build, original software and documentation. CHAIR and Philipp Schmalfuß: physical models and helpers. Tom Erbe: Chris Moore reverb, included through CHAIR. Miller Puckette and contributors: Pure Data and included examples.

[LICENSE](LICENSE) covers Peter’s original software and documentation. [THIRD-PARTY.md](THIRD-PARTY.md) maps upstream terms to the included material.

[made by atelier neyra](https://atelierneyra.com)
